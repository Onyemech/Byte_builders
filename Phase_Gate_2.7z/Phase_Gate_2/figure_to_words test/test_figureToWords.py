import unittest
import figureToWords

class TestFigureToWords(unittest.TestCase)
	def test_that_figureToWords_function_exist(self)
		figureToWords.number_to_words("7", "5")

	