def number_to_words(num1, num2):

	result = int(num1) + int(num2)
	print(str(result))

number_to_words("7", "5")
